var quienempieza;

function empezarJuego(){
    quienempieza = (Math.floor(Math.random() * 2));
    console.log(quienempieza);
    if (quienempieza === 0) {
        document.getElementById("turno").style.color = Storage.get("jugador1").color;
        document.getElementById("turno").innerHTML = "Turno de: " + Storage.get("jugador1").apodo;        
    } else {
        document.getElementById("turno").style.color = Storage.get("jugador2").color;
        document.getElementById("turno").innerHTML = "Turno de: " + Storage.get("jugador2").apodo;        
    }  
}

